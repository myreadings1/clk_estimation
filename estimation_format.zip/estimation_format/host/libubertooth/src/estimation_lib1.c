/*
 * Copyright 2010, 2011 Michael Ossmann
 *
 * This file is part of Project Ubertooth.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 51 Franklin Street,
 * Boston, MA 02110-1301, USA.
 */


#include "estimation_lib1.h"
//#include "math.h"

//////////////////////////////////////////////////////////////
/* generate the complete hopping sequence */
static void gen_hops( struct _GT_SEQ_ *GT_SEQ )
{
	/* a, b, c, d, e, f, x, y1, y2 are variable names used in section 2.6 of the spec */
	/* b is already defined */
	/* e is already defined */
	int a, c, d, f, x;
	int h, i, j, k, c_flipped, perm_in, perm_out;

	/* sequence index = clock >> 1 */
	/* (hops only happen at every other clock value) */
	int index = 0;
	f = 0;

	/* nested loops for optimization (not recalculating every variable with every clock tick) */
	for (h = 0; h < 0x04; h++) { /* clock bits 26-27 */
		for (i = 0; i < 0x20; i++) { /* clock bits 21-25 */
			a = GT_SEQ->a1 ^ i;
			for (j = 0; j < 0x20; j++) { /* clock bits 16-20 */
				c = GT_SEQ->c1 ^ j;
				c_flipped = c ^ 0x1f;
				for (k = 0; k < 0x200; k++) { /* clock bits 7-15 */
					d = GT_SEQ->d1 ^ k;
					for (x = 0; x < 0x20; x++) { /* clock bits 2-6 */
						perm_in = ((x + a) % 32) ^ GT_SEQ->b;
						/* y1 (clock bit 1) = 0, y2 = 0 */
						perm_out = perm5(perm_in, c, d);
						GT_SEQ->GT_seq[index] = GT_SEQ->bank[(perm_out + GT_SEQ->e + f) % BT_CHANNELS];
						if (GT_SEQ->AFH_MODE) {
							GT_SEQ->GT_seq [ index + 1 ] = GT_SEQ->GT_seq [ index ];
						} else {
							/* y1 (clock bit 1) = 1, y2 = 32 */
							perm_out = perm5 (perm_in, c_flipped, d);
							GT_SEQ->GT_seq[index + 1] = GT_SEQ->bank[(perm_out + GT_SEQ->e + f + 32) % BT_CHANNELS];
						}
						index += 2;
					}
					f += 16;
				}
			}
		}
	}
}
////////////////////////////////////
static void address_precalc ( struct _GT_SEQ_ *GT_SEQ)
{
	int i;
	uint32_t address = GT_SEQ->address;
	/* populate frequency register bank*/
	for (i = 0; i < BT_CHANNELS; i++)
			GT_SEQ->bank[i] = ((i * 2) % BT_CHANNELS);
	/* actual frequency is 2402 + pn->bank[i] MHz */


	/* precalculate some of single_hop()/gen_hop()'s variables */
	GT_SEQ->a1 = (address >> 23) & 0x1f;
	GT_SEQ->b = (address >> 19) & 0x0f;
	GT_SEQ->c1 = ((address >> 4) & 0x10) +
		((address >> 3) & 0x08) +
		((address >> 2) & 0x04) +
		((address >> 1) & 0x02) +
		(address & 0x01);
	GT_SEQ->d1 = (address >> 10) & 0x1ff;
	GT_SEQ->e = ((address >> 7) & 0x40) +
		((address >> 6) & 0x20) +
		((address >> 5) & 0x10) +
		((address >> 4) & 0x08) +
		((address >> 3) & 0x04) +
		((address >> 2) & 0x02) +
		((address >> 1) & 0x01);
}
////////////////////////////////////
// use GT_seq to find out CLK candidates
static void init_candidates ( struct _GT_SEQ_ *GT_SEQ )
{
	int i, k=0; 
	uint8_t ch = GT_SEQ->listen_ch;
	/* populate frequency register bank*/

	for (i = 0; i < SEQUENCE_LENGTH ; i++){

		if (ch == GT_SEQ->GT_seq[ i ]){
			GT_SEQ->CLK_candinc [ k ] = i;
			k++;	  
		}
	}
	/* actual frequency is 2402 + pn->bank[i] MHz */
	printf ("\nnum_cand = %d\n", k );
	GT_SEQ->num_candinc  = k;
}

//////////////////////////////////////////////////////////////////////////////////
//static const char * const TYPE_NAMES[] = {
//	"NULL", "POLL", "FHS", "DM1", "DH1/2-DH1", "HV1", "HV2/2-EV3", "HV3/EV3/3-EV3",
//	"DV/3-DH1", "AUX1", "DM3/2-DH3", "DH3/3-DH3", "EV4/2-EV5", "EV5/3-EV5", "DM5/2-DH5", "DH5/3-DH5"

///////////////////////////////////////////////////////////////////////////////////
static uint32_t hamm_ds5_inc072 (const struct _GT_SEQ_ *GT_SEQ, struct _ShMemory  *ShmPTR, const int l, const int trails)

{
//dts      = is a list of distances (# of slots) between consecutive pkts of the same class
// l       = is the length of CLK6_1
// CLK_candinc [j] = CLK candidates extracted from GT assuming ubertooth listens to ch=39
// num_candinc = # of CLK candidates
	int i,j, cand_hamm2, max_hamm2=0;
	uint32_t cand, dst_to_fst=0, Winner_cand=0, Winner_cand_idx_jj = 0;
	for (j = 0; j < GT_SEQ->num_candinc - l; j++ )
	{

		dst_to_fst=0; cand_hamm2=0; 

		// take one cand atime
		cand = GT_SEQ->CLK_candinc [j]; 

		// for each incoming candidate cand find the distance between cand and the list
		for (i=0 ; i < l; i++)
		{

			dst_to_fst = dst_to_fst + ShmPTR->OneCh_slts [ i + trails + 1 ];

			if ( LISTEN_CHANNEL == GT_SEQ->GT_seq [ ( cand + dst_to_fst ) % SEQUENCE_LENGTH  ] )
				{cand_hamm2++; }

		}


		if ( (l/4) <= cand_hamm2)  
		{

			if ( (63 & cand) == ShmPTR->OneCh_clk6_1 [ trails ]  )
			{
				if (max_hamm2 <= cand_hamm2)
				{
					max_hamm2 = cand_hamm2; 

					Winner_cand = cand ;
					Winner_cand_idx_jj = j ;

//					candd1 = cand ;
//					candd1_idx_jj = j ;
				}
				printf (       "hamm2 %d, %u, %u\n", cand_hamm2, cand, Winner_cand);
//				fprintf (fout, "%d, %u, %u\n", cand_hamm2, cand, candd1);
//				++ found_cand ;
			}

		}

	}

out:
	ShmPTR->wCand 		= Winner_cand;
	ShmPTR->wCand_idx_jj 	= Winner_cand_idx_jj;
	return 0;
}
/////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////
static int read_Seq_File ( struct _GT_SEQ_ *GT_SEQ  )
{
	FILE * pFile;

	uint32_t address = GT_SEQ->address;
	int seq_length, num_candinc;
	char buf [1024];

	memset (buf,0,1024);
	sprintf ( buf, "%u_seq_length", address );
	pFile = fopen (buf, "r");
	if ( NULL == pFile) { printf ("Err open hop seq files..\n"); exit(0) ; }
	fscanf (pFile, "%d", &seq_length );
	fclose (pFile);
	GT_SEQ->seq_length = seq_length;

	memset (buf,0,1024);
	sprintf ( buf, "%u_n_cands", address );
	pFile = fopen (buf, "r");
	if ( NULL == pFile) { printf ("Err open hop seq files..\n"); exit(0) ; }
	fscanf (pFile, "%d", &num_candinc );
	fclose (pFile);
	GT_SEQ->num_candinc = num_candinc;

	memset (buf,0,1024);
	sprintf ( buf, "%u_hops", address );
	pFile = fopen (buf, "rb");
	if ( NULL == pFile) { printf ("Err open hop seq files..\n"); exit(0) ; }
	fread (GT_SEQ->GT_seq, GT_SEQ->seq_length, sizeof(uint8_t) , pFile);
	fclose (pFile);

	memset (buf,0,1024);
	sprintf ( buf, "%u_cands", address );
	pFile = fopen (buf, "rb");
	if ( NULL == pFile) { printf ("Err open hop seq files..\n"); exit(0) ; }
	fread (GT_SEQ->CLK_candinc, GT_SEQ->num_candinc, sizeof(uint32_t), pFile);
	fclose (pFile);


  return 0;
}
///////////////////////////////////////
static void write_Seq_File ( struct _GT_SEQ_ *GT_SEQ  )
{
	FILE * pFile;
	uint32_t address = GT_SEQ->address;

	char buf [1024];
	memset (buf,0,1024);
	sprintf ( buf, "%u_seq_length", address );
	if ( NULL == (pFile = fopen (buf, "w") ) )
	{
		printf ("Err write seq\n");	exit ( 0 );
	}

	fprintf (pFile, "%ld", GT_SEQ->seq_length );
	fclose (pFile);

	memset (buf,0,1024);
	sprintf ( buf, "%u_n_cands", address );
	if ( NULL == (pFile = fopen (buf, "w") ) )
	{
		printf ("Err write seq\n");	exit ( 0 );
	}

	fprintf (pFile, "%d", GT_SEQ->num_candinc );
	fclose (pFile);

	memset (buf,0,1024);
	sprintf ( buf, "%u_hops", address );
	if ( NULL == (pFile = fopen (buf, "wb") ) )
	{
		printf ("Err write seq\n"); exit ( 0 );
	}

	if (0 == fwrite (GT_SEQ->GT_seq , GT_SEQ->seq_length, sizeof(uint8_t) , pFile) )
	{
		printf ("Err write bin\n"); exit ( 0 );
	}

	fclose (pFile);

	memset (buf,0,1024);
	sprintf ( buf, "%u_cands", address );
	if ( NULL == (pFile = fopen (buf, "wb") ) )
	{
		printf ("Err write seq\n");
		exit ( 0 );
	}

	if (0 == fwrite (GT_SEQ->CLK_candinc , GT_SEQ->num_candinc, sizeof(uint32_t), pFile) )
	{
		printf ("Err write bin\n");	exit ( 0 );
	}

	fclose (pFile);

//  return 0;
}
/////////////////////////////////////////////////////////////
void init_GT_SEQ ( struct _GT_SEQ_ *GT_SEQ , uint8_t hasSeqFile)
{
	// We are working on AFH79
	uint32_t address = GT_SEQ->address;
	uint8_t listen_ch = GT_SEQ->listen_ch;

	GT_SEQ->GT_seq 		= (uint8_t  *) calloc(SEQUENCE_LENGTH, sizeof (uint8_t) );
	GT_SEQ->CLK_candinc 	= (uint32_t *) calloc(SEQUENCE_LENGTH/16, sizeof (uint32_t));
	
	if ( NULL ==  GT_SEQ->GT_seq)
	{
		printf ("Err allocate GT_seq\n");exit (0);
	}

	if ( NULL ==  GT_SEQ->CLK_candinc)
	{
		printf ("Err allocate GT_seq\n");exit (0);
	}

	GT_SEQ->seq_length = SEQUENCE_LENGTH;
	// Do precalculation
	address_precalc( GT_SEQ );

	if ( 0 == hasSeqFile )
	{
	//Generate the ground truth seque
		gen_hops( GT_SEQ );
	// Generate a list of CLK cand, specify a channel CHANNEL = 39
		init_candidates ( GT_SEQ );
	// write hops & cand to a file
		write_Seq_File ( GT_SEQ );
	}
	else 
	// read hops & cand from a file
	{
		read_Seq_File ( GT_SEQ );
	}



}


void deinit_GT_SEQ ( struct _GT_SEQ_ *GT_SEQ )
{
	free (GT_SEQ->GT_seq	  );
	free (GT_SEQ->CLK_candinc );
}

////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////
void init_shmem  ( struct _ShMemory *shm )
{
	shm->OneCh_clk6_1 		= (uint8_t  *) malloc ( MAX_PKTS_IN_FILE );
	shm->OneCh_slts 		= (int      *) malloc ( MAX_PKTS_IN_FILE );
}
/////////////////////////////////////////////////////
void deinit_shmem ( struct _ShMemory *shm )
{
	free (shm->OneCh_clk6_1	  );
	free (shm->OneCh_slts	  );
}

/////////////////////////////////////////////////////////////////////////////////
int read_pkts_from_file2 ( struct _ShMemory *ShmPTR, const int max_pkts_to_read )

{

	FILE * pFile, *fout;
	int round_slts=0, n_pkts ;
	float slots;
	uint32_t pkt_time, pkt_LAP, prev_pkt_time = 0xffffffff;
	uint8_t pkt_clk6_1, pkt_type, pkt_LT_ADD, pkt_rx_channel, prev_clk6_1 = 0;

//	pFile = fopen ("tafh79_111","r");
//	pFile = fopen ("tafh79_ch39_1","r");
//	pFile = fopen ("new_afh79","r");
//	pFile = fopen ("tdata_afh79_ch39_1","r");
	pFile = fopen ("tdata_afh79_ch39_3","r");
//	pFile = fopen ("tsound_jam20_ch39_1","r");
//	pFile = fopen ("tsound_jam40_ch39_1","r");
	if (NULL == pFile) { printf ("Err open file"); goto out; }

	n_pkts = 0 ;
// Read pkt loop
	while ( 1 )
	{


		fscanf (pFile, "%"SCNu8", %"SCNu8", %"SCNu8", %"SCNu8", %6x, %u, %d, %f", 
		&pkt_clk6_1, 
		&pkt_type, 
		&pkt_LT_ADD, 
		&pkt_rx_channel, 
		&pkt_LAP, 
		&pkt_time, 
		&round_slts,
		&slots
		);

		if (feof(pFile)) break;

//		if ( MAX_PKTS_IN_FILE <= n_pkts) break;
		if ( max_pkts_to_read <= n_pkts) break;

//		printf ("%"SCNu8", %"SCNu8", %"SCNu8", %"SCNu8", %6x, %u, %d, %f\n", 
//		pkt_clk6_1, 
//		pkt_type, 
//		pkt_LT_ADD, 
//		pkt_rx_channel, 
//		pkt_LAP, 
//		pkt_time, 
//		round_slts,
//		slots
//		);


		ShmPTR->OneCh_slts 	[ n_pkts ] = round_slts;
		ShmPTR->OneCh_clk6_1    [ n_pkts ] = pkt_clk6_1;

		++ n_pkts;
//	if ( 5 < n_pkts) 
//		break ;
	}


	ShmPTR->OneCh_npkts = n_pkts ;

	fclose (pFile);
	return n_pkts;

out:
	return 0;

}

/////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////

