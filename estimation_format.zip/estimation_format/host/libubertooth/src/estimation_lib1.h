/*
 * Copyright 2010 - 2013 Michael Ossmann, Dominic Spill, Will Code, Mike Ryan
 *
 * This file is part of Project Ubertooth.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 51 Franklin Street,
 * Boston, MA 02110-1301, USA.
 */

#ifndef __ESTIMATION_LIB1__
#define __ESTIMATION_LIB1__

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <math.h>
#include <inttypes.h>

//#define MAX_PKTS_IN_FILE 30000
#define BT_CHANNELS 		79
#define SEQUENCE_LENGTH 	134217728
#define LISTEN_CHANNEL 		39

#define MAX_PKTS_IN_FILE 30000
//#define MAX_PKTS_IN_FILE1 30
#define MAX_LIST_SIZE 2048

//////////////////////////////////////////////////////////////

struct _GT_SEQ_ {
	/* these values for hop() can be precalculated in part (e.g. a1 is the
	 * precalculated part of a) */
	uint32_t a1, b, c1, d1, e;
	uint8_t AFH_MODE;
	uint32_t address;
	uint8_t listen_ch;

	// SEQUENCE_LENGTH = 134217728
	uint8_t *GT_seq ;
	uint8_t bank[BT_CHANNELS];

	//134217728/64=2097152
	uint32_t *CLK_candinc ;

	//number of candidates
	int num_candinc;
	long int seq_length;

} ;
////////////////////////////////////////////////////////////
struct _ShMemory {

////////// CLK acq
	uint8_t 	OneCh_status;
//	uint8_t 	OneCh_clk6_1     	[ MAX_PKTS_IN_FILE ];
//	int 		OneCh_slts 	 	[ MAX_PKTS_IN_FILE ];

	uint8_t 	* OneCh_clk6_1     	;
	int 		* OneCh_slts 		;

	int 		OneCh_npkts;


	uint32_t 	wCand ;
	uint32_t 	wCand_idx_jj ;

};

////////////////////////////////////////////////////////
void 		init_GT_SEQ ( struct _GT_SEQ_ *GT_SEQ , uint8_t hasSeqFile);
void 		deinit_GT_SEQ 	( struct _GT_SEQ_ *GT_SEQ );
//void 	Find_TargetCLK 	( struct ShMemory  *ShmPTR, struct _GT_SEQ_ *GT_SEQ  );


static void 	write_Seq_File ( struct _GT_SEQ_ *GT_SEQ  );
static int 	read_Seq_File ( struct _GT_SEQ_ *GT_SEQ  );
static void 	gen_hops( struct _GT_SEQ_ *GT_SEQ );
static void 	address_precalc ( struct _GT_SEQ_ *GT_SEQ);
static void 	init_candidates ( struct _GT_SEQ_ *GT_SEQ );

////////////////////
void 		init_shmem  ( struct _ShMemory *shm );
void 		deinit_shmem ( struct _ShMemory *shm );
int 		read_pkts_from_file2 ( struct _ShMemory *ShmPTR, const int max_pkts_to_read );


///////////////////////////////////////////////////////

#endif /* __UBERTOOTH_H__ */
